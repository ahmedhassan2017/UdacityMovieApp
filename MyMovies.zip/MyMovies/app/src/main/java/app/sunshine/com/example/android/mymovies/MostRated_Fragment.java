package app.sunshine.com.example.android.mymovies;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class MostRated_Fragment extends Fragment implements MoviesAdapter.ListItemClickListener{

    LinearLayoutManager mLayoutManager;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View root = inflater.inflate(R.layout.fragment_most_rated_, container, false);


        RecyclerView recyclerView = root.findViewById(R.id.recyclerView1);
//        mLayoutManager = new LinearLayoutManager(this.getActivity());
//        Log.d("debugMode", "The application stopped after this");
//        recyclerView.setLayoutManager(mLayoutManager);
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(
                2, LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(staggeredGridLayoutManager); // set LayoutManager to RecyclerView


        MoviesAdapter adapter = new MoviesAdapter(this.getActivity(), new ArrayList<Movie>(), this);// list of movies
        MyAsyncTask task1 = new MyAsyncTask(adapter);
        task1.execute("http://api.themoviedb.org/3/movie/top_rated?api_key=600908f259c6e4fe3bbba5ce046ee937");
        recyclerView.setAdapter(adapter);



        return root;
    }



    @Override
    public void onListItemClick(Movie movieitem) {
        Intent intent = new Intent(getActivity(),Detailes_Fragment.class);
        intent.putExtra("item",movieitem);
        startActivity(intent);

    }
}




